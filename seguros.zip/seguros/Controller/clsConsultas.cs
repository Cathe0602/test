﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data;

namespace seguros.Controller
{
    public class clsConsultas
    {
        private static String strConn = ConfigurationManager.ConnectionStrings["connString"].ToString();
        public static DataSet dsCompania;
        public static DataSet dsProdCompania;

        public static bool GetInfoCompanias()
        {
            bool result = true;
            OleDbConnection oleDbConn = new OleDbConnection();
            try
            {
                oleDbConn.ConnectionString = strConn;
                oleDbConn.Open();
                String sqlCmd = "select * from fal_Compania where eliminado = 0 ORDER BY RazonSocial ";
                
                OleDbCommand qryInfoCompanias = new OleDbCommand(sqlCmd, oleDbConn);
                qryInfoCompanias.CommandType = CommandType.Text;

                OleDbDataAdapter adapter = new OleDbDataAdapter(qryInfoCompanias);
                dsCompania = new DataSet();
                adapter.Fill(dsCompania);
            }
            catch (Exception err)
            {
                result = false;
            }
            finally
            {
                oleDbConn.Close();
            }
            return result;
        }

        public static bool AddInfoCompania(string Razon, string Nit, string Dir, string Tel)
        {
            bool dbResult = true;
            OleDbConnection oleDbConn = new OleDbConnection();
            try
            {
                oleDbConn.ConnectionString = strConn;
                oleDbConn.Open();
                String sqlCmd = "insert into fal_Compania (RazonSocial, Nit, Direccion, Telefono, FechaCreacion) values (?,?,?,?,?)";
                List<OleDbParameter> parametros = new List<OleDbParameter>();
                //parametros.Add(new OleDbParameter("@Id_compania", 2));
                parametros.Add(new OleDbParameter("@RazonSocial", Razon));
                parametros.Add(new OleDbParameter("@Nit", Nit));
                parametros.Add(new OleDbParameter("@Direccion", Dir));
                parametros.Add(new OleDbParameter("@Telefono", Tel));
                parametros.Add(new OleDbParameter("@FechaCreacion", DateTime.Now));

                OleDbCommand qryInfoCompanias = new OleDbCommand(sqlCmd, oleDbConn);
                qryInfoCompanias.CommandType = CommandType.Text;
                qryInfoCompanias.Parameters.Clear();
                qryInfoCompanias.Parameters.AddRange(parametros.ToArray());
                dbResult = (qryInfoCompanias.ExecuteNonQuery() != 0);
                //OleDbDataAdapter adapter = new OleDbDataAdapter(qryInfoCompanias);
                //dsCompania = new DataSet();
                //adapter.Fill(dsCompania);
            }
            catch (Exception err)
            {
                dbResult = false;
            }
            finally
            {
                oleDbConn.Close();
            }
            return dbResult;
        }

        public static bool GetInfoProdCompanias(int Id_compania)
        {
            bool result = true;
            OleDbConnection oleDbConn = new OleDbConnection();
            try
            {
                oleDbConn.ConnectionString = strConn;
                oleDbConn.Open();
                String sqlCmd = string.Format("select p.Name, cp.Prima, cp.Cobertura, cp.Asistencia from fal_CondicionesXprod cp inner join fal_Productos p on cp.Id_prod=p.Id_prod inner join fal_ProdXcompania pc on pc.Id_condXprod=cp.Id_condicionesProd where pc.Id_Compania={0}", Id_compania);
                OleDbCommand qryInfoProdCompanias = new OleDbCommand(sqlCmd, oleDbConn);
                qryInfoProdCompanias.CommandType = CommandType.Text;

                OleDbDataAdapter adapter = new OleDbDataAdapter(qryInfoProdCompanias);
                dsProdCompania = new DataSet();
                adapter.Fill(dsProdCompania);
            }
            catch (Exception err)
            {
                result = false;
            }
            finally
            {
                oleDbConn.Close();
            }
            return result;
        }
    }

}