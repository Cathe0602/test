﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using seguros.Controller;

namespace seguros
{
    public partial class Company : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindInfo();
        }
        public void BindInfo()
        {
            if (clsConsultas.GetInfoCompanias())
            {
                gvCompanies.DataSource = clsConsultas.dsCompania;
                gvCompanies.DataBind();
            }
        }

        protected void lnkGuardar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TxtCompania.Text) && !string.IsNullOrEmpty(TxtNit.Text) && !string.IsNullOrEmpty(TxtDir.Text) && !string.IsNullOrEmpty(TxtTel.Text))
            {
                clsConsultas.AddInfoCompania(TxtCompania.Text, TxtNit.Text, TxtDir.Text, TxtTel.Text);
                BindInfo();
            }
            else
                msgAlerta.Text = "Faltan campos por llenar.";
            
        }
        protected void gvCompanies_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Editar")
            {
                Response.Redirect("~/Company.aspx");
            }
            else if (e.CommandName == "Productos")
            {
                Response.Redirect("~/DetailCompany.aspx");
            }
            else if (e.CommandName == "Clientes")
            {
                Response.Redirect("~/Client.aspx");
            }
        }
    }
}