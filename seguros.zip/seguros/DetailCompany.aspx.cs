﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using seguros.Controller;

namespace seguros
{
    public partial class DetailCompany : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void BindInfo()
        {
            int id_compania = 0;
            if (clsConsultas.GetInfoProdCompanias(id_compania))
            {
                gvProds.DataSource = clsConsultas.dsProdCompania;
                gvProds.DataBind();
            }
        }
    }
}